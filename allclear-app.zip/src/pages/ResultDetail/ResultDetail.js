import React, { Fragment } from 'react';
import states from './ResultDetail.state';

  
class ResultDetail extends React.Component {
    state = states
    componentDidMount = () => {

    }

    handleInputChange = (event, name) => {

    }


    render() {
        return (
            <Fragment>

            </Fragment>
        )
    }
}
export default ResultDetail