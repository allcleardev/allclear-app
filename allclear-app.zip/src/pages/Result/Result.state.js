
export const resultObjDefault = () => {
    return 
        {
    }
}

const states = (function states() {
    return {
        resultObj: resultObjDefault(),
    }
})()
export default states;
