
export const symptomObjDefault = () => {
    return 
        {
    }
}

const states = (function states() {
    return {
        symptomObj: symptomObjDefault(),
    }
})()
export default states;
