
export const conditionObjDefault = () => {
    return 
        {
    }
}

const states = (function states() {
    return {
        conditionObj: conditionObjDefault(),
    }
})()
export default states;
